// src/pages/level2/Level2Background.jsx
import React from 'react';
import './Level2Background.css'; // Crearemos este archivo para estilos

const Level2Background = () => {
  return (
    <div className="level2-background"></div>
  );
};

export default Level2Background;
